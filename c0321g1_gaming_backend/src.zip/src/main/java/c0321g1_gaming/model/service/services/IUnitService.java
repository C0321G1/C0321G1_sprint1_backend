package c0321g1_gaming.model.service.services;

import c0321g1_gaming.model.entity.services.Unit;

import java.util.List;

public interface IUnitService {
    List<Unit> findAll();
}
