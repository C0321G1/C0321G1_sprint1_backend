package c0321g1_gaming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C0321g1GamingApplication {

    public static void main(String[] args) {
        SpringApplication.run(C0321g1GamingApplication.class, args);
    }

}
