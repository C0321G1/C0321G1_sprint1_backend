package c0321g1_gaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C0321g1GamingApplicationTests {

    @Test
    void contextLoads() {
    }

}
